g++ read.cpp -o read
mpic++ test.cpp -fopenmp -o test